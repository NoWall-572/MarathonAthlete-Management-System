#include "genderdelegate.h"

